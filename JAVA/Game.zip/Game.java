import java.util.Scanner;
import java.util.InputMismatchException;

class ErrorInputException extends Exception {
    @Override
    public void printStackTrace() {
        System.out.print("Please enter the valid Rock-Paper-Scissors: 1-3.");
    }
}

class Player {
    private int choice;

    public void setChoice(int choice) throws ErrorInputException {
        if (choice < 1 || choice > 3) {
            throw new ErrorInputException();
        }
        this.choice = choice;
    }

    public int getChoice() {
        return choice;
    }
}

class Game {
    public static String getResult(int a, int b) {
        if (a == b) return "get a drew";
        if ((a == 1 && b == 2) || (a == 2 && b == 3) || (a == 3 && b == 1)) return "A wins";
        return "B wins";
    }
}

public class Game {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] res = new String[3];
        Player playerA = new Player();
        Player playerB = new Player();
        int round = 0;

        try {
            while (true) {
                if (round >= res.length) {
                    System.out.print("Round " + (round + 1) + ", 3 rounds at most. Please enter choice of PlayerA: 1-Rock, 2-Scissors, 3-Paper:\n");
                    int inputA = readChoice(sc, playerA);
                    System.out.print("Round " + (round + 1) + ", 3 rounds at most. Please enter choice of PlayerB: 1-Rock, 2-Scissors, 3-Paper:\n");
                    int inputB = readChoice(sc, playerB);

                    throw new ArrayIndexOutOfBoundsException();
                }

                System.out.print("Round " + (round + 1) + ", 3 rounds at most. Please enter choice of PlayerA: 1-Rock, 2-Scissors, 3-Paper:\n");
                int inputA = readChoice(sc, playerA);

                System.out.print("Round " + (round + 1) + ", 3 rounds at most. Please enter choice of PlayerB: 1-Rock, 2-Scissors, 3-Paper:\n");
                int inputB = readChoice(sc, playerB);

                String result = Game.getResult(playerA.getChoice(), playerB.getChoice());
                res[round] = result;
                System.out.println(result);

                round++;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.print("Exceed the maximal rounds.");
        }
    }

    private static int readChoice(Scanner sc, Player player) {
        try {
            int input = sc.nextInt();
            player.setChoice(input);
            return input;
        } catch (InputMismatchException e) {
            sc.nextLine();
            System.out.println("Please enter the valid Rock-Paper-Scissors: 1-3.");
            System.exit(0);
        } catch (ErrorInputException e) {
            e.printStackTrace();
            System.exit(0);
        }
        return -1; 
    }
}
