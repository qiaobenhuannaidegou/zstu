package com.example;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.util.Duration;

public class controller {
    @FXML private Label TimeLabel;
    @FXML private Canvas canvas;
    @FXML private BorderPane rootpane;

    private Timeline Timeupdater;
    private Timeline fanAnimation;
    private double angle = 0;
    private double speed = 7;
    private boolean running = false;

    public void initialize() {
        Timeupdater = new Timeline(new KeyFrame(Duration.seconds(1), e ->{
            String Time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            TimeLabel.setText(Time);
        }));

        Timeupdater.setCycleCount(Timeline.INDEFINITE);
        Timeupdater.play();
        
        drawFan();

        fanAnimation = new Timeline(new KeyFrame(Duration.millis(100), e -> {
            if(running) {
                angle += speed;
                drawFan();
            }
        }));
        fanAnimation.setCycleCount(Timeline.INDEFINITE);
        fanAnimation.play();

        canvas.setOnMouseClicked(etv -> toggleFan());
        canvas.setFocusTraversable(true);
        canvas.setOnKeyPressed(this::handleKeyEvent);
        Platform.runLater(() -> {
            rootpane.requestFocus(); 
            rootpane.setOnKeyPressed(this::handleKeyEvent);
        });
    }

    private void drawFan(){
        double w = canvas.getWidth();
        double h = canvas.getHeight();
        double centerX = w/2;
        double centerY = h/2;
        double radius = Math.min(w,h) * 0.4;

        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, w, h);

        gc.setStroke(Color.BLACK);
        gc.strokeOval(centerX - radius, centerY - radius, radius * 2, radius * 2);

        gc.setFill(Color.RED);
        for(int i=0;i < 5; i++){
            double startAngle = angle + i*72;
            gc.fillArc(centerX - radius,centerY - radius, radius * 2, radius * 2, startAngle, 40, ArcType.ROUND);
        }
    }

    private void toggleFan(){
        running = !running;
    }

    private void handleKeyEvent(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            toggleFan();
        } else if (event.getCode() == KeyCode.UP) {
            speed += (speed > 0 ? 1 : -1);
        } else if (event.getCode() == KeyCode.DOWN) {
            if (Math.abs(speed) > 1)
                speed -= (speed > 0 ? 1 : -1);
        }
    } 

    @FXML 
    private void handleLeft() {
        speed = -Math.abs(speed);
    }

    @FXML
    private void handleRight() {
        speed = Math.abs(speed);
    }

    @FXML
    private void handlePause() {
        toggleFan();
    }

    @FXML
    private void handleSpeedUp() {
        speed += (speed > 0 ? 1 : -1);
    }

    @FXML
    private void handleSpeedDown() {
        if (Math.abs(speed) > 1)
            speed -= (speed > 0 ? 1 : -1);
    }
}
