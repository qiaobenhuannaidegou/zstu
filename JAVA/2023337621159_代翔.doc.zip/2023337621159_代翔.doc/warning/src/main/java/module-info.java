module com.example {
    requires javafx.fxml;
    requires transitive javafx.controls;
    requires javafx.graphics;
    requires javafx.base;

    exports com.example;
    opens com.example to javafx.fxml;
}