import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SumAnswer {
    public enum TaskType {
        WITHOUT_SYN,
        SYN_METHOD,
        SYN_STATEMENT,
        LOCK
    }

    private static void testExecutor(String label, ExecutorService executorService, TaskType type, int taskCount) {
        SharedSum shared = new SharedSum();
        Lock sharedLock = new ReentrantLock();

        for (int i = 0; i < taskCount; i++) {
            Runnable task;
            switch (type) {
                case WITHOUT_SYN:
                    task = new SumTaskWithoutSyn(shared);
                    break;
                case SYN_METHOD:
                    task = new SumTaskWithSynMet(shared);
                    break;
                case SYN_STATEMENT:
                    task = new SumTaskWithSynStat(shared);
                    break;
                case LOCK:
                    task = new SumTaskWithLock(shared, sharedLock);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown TaskType");
            }
            executorService.execute(task);
        }

        executorService.shutdown();
        try {
            executorService.awaitTermination(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.printf("[%s] Final sum = %d\n", label, shared.sum);
    }

    public static void main(String[] args) {
        int taskCount = 1000;

        testExecutor("FixedThreadPool (No Sync)", Executors.newFixedThreadPool(100), TaskType.WITHOUT_SYN, taskCount);
        testExecutor("FixedThreadPool (Synchronized Method)", Executors.newFixedThreadPool(100), TaskType.SYN_METHOD, taskCount);
        testExecutor("FixedThreadPool (Synchronized Block)", Executors.newFixedThreadPool(100), TaskType.SYN_STATEMENT, taskCount);
        testExecutor("FixedThreadPool (Lock)", Executors.newFixedThreadPool(100), TaskType.LOCK, taskCount);
        testExecutor("CachedThreadPool (No Sync)", Executors.newCachedThreadPool(), TaskType.WITHOUT_SYN, taskCount);
    }
}
