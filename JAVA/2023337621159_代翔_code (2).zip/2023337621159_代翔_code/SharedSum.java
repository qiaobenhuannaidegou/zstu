public class SharedSum {
    public int sum = 0;
}
