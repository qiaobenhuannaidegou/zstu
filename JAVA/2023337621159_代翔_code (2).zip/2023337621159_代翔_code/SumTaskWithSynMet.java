public class SumTaskWithSynMet implements Runnable{
    private SharedSum shared;

    public SumTaskWithSynMet(SharedSum shared) {
        this.shared = shared;
    }

    private synchronized void increment(){
        shared.sum++;
    }

    @Override
    public void run(){
        increment();
    } 
}
