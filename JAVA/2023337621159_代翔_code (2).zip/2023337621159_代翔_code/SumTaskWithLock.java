import java.util.concurrent.locks.Lock;

public class SumTaskWithLock implements Runnable{
    private  SharedSum shared;
    private  Lock lock;

    public SumTaskWithLock(SharedSum shared, Lock lock){
        this.lock = lock;
        this.shared = shared;
    }

    @Override
    public void run(){
        lock.lock();
        try {
            shared.sum++;
        } finally {
            lock.unlock();
        }
    }
}
