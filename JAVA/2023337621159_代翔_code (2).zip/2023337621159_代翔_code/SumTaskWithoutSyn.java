public class SumTaskWithoutSyn implements Runnable{
    private SharedSum shared;

    public SumTaskWithoutSyn(SharedSum shared) {
        this.shared = shared;
    }

    @Override
    public void run(){
        shared.sum++;
    }
}