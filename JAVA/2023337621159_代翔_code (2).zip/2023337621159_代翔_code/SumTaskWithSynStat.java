public class SumTaskWithSynStat implements Runnable {
    private SharedSum shared;

    
    public SumTaskWithSynStat(SharedSum shared) {
        this.shared = shared;
    }

    @Override
    public void run(){
        synchronized (shared) {
            shared.sum++;
        }
    }
}
