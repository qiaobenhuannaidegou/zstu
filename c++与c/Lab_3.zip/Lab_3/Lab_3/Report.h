#pragma once
#include <vector>
#include "Employee.h"
#include <algorithm>

class report
{
	vector<Mangager>* MA_list = new vector<Mangager>();
	vector<Technician>* T_list = new vector<Technician>();
	vector<Salesperson>* SP_list = new vector<Salesperson>();

public:
	void operator [](string index)
	{
		if (index == "mangager")
		{
			for (auto it = MA_list->begin(); it != MA_list->end(); it++)
			{
				cout << "ID: " << it->ID << "," << "NAME: " << it->name << "SALARY: " << it->get_pay() << ",";
				printf("%04d/%02d/%02d-%02d:%02d:%02d\n", it->enroll_date.wYear, it->enroll_date.wMonth, it->enroll_date.wDay, it->enroll_date.wHour, it->enroll_date.wMinute, it->enroll_date.wSecond);
			}
		}
		else if (index == "technician")
		{
			for (auto it = T_list->begin(); it != T_list->end(); it++)
			{
				cout << "ID: " << it->ID << "," << "NAME: " << it->name << "SALARY: " << it->get_pay() << ",";
				printf("%04d/%02d/%02d-%02d:%02d:%02d\n", it->enroll_date.wYear, it->enroll_date.wMonth, it->enroll_date.wDay, it->enroll_date.wHour, it->enroll_date.wMinute, it->enroll_date.wSecond);
			}
		}
		else if (index == "salesperson")
		{
			for (auto it = SP_list->begin(); it != SP_list->end(); it++)
			{
				cout << "ID: " << it->ID << "," << "NAME: " << it->name << "SALARY: " << it->get_pay() << ",";
				printf("%04d/%02d/%02d-%02d:%02d:%02d\n", it->enroll_date.wYear, it->enroll_date.wMonth, it->enroll_date.wDay, it->enroll_date.wHour, it->enroll_date.wMinute, it->enroll_date.wSecond);
			}
		}
		else
		{
			cout << "Error" << endl;
		}
	}

	void insert(Mangager a);
	void insert(Technician b);
	void insert(Salesperson c);

	void print(string position);
};