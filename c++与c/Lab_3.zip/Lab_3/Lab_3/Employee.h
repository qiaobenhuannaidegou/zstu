#pragma once
#include <iostream>
using namespace std;
#include <string>
#include <Windows.h>
class Time
{
public:
	SYSTEMTIME cur_time;
public:
	SYSTEMTIME get_time()
	{
		GetLocalTime(&cur_time);
		return cur_time;
	}
};

class Employee
{
protected:
	string ID;
	string name;
	string gender;
	SYSTEMTIME enroll_date;
	string position;
	double salary;
public:
	virtual double get_pay() = 0;
};

class Mangager:virtual Employee
{
	friend class report;
	friend ostream& operator<<(ostream& out, Mangager MA);
	double bonus;
public:
	Mangager(string p_ID, string p_name, string p_gender, double p_salary, double p_bonus);
	double get_pay();
};

class Technician :virtual Employee
{
	friend class report;
	friend ostream& operator<<(ostream& out, Technician TE);
public:
	Technician(string p_ID, string p_name, string p_gender, double p_salary);
	double get_pay();
};

class Salesperson :virtual Employee
{
	friend class report;
	friend ostream& operator<<(ostream& out, Salesperson SA);
	double profits;
public:
	Salesperson(string p_ID, string p_name, string p_gender, double p_salary, double p_profits);
	double get_pay();
};