#include "Report.h"


void report::insert(Mangager a)
{
	MA_list->push_back(a);
}

void report::insert(Technician b)
{
	T_list->push_back(b);
}

void report::insert(Salesperson c)
{
	SP_list->push_back(c);
}

bool compare(Mangager& a, Mangager& b)
{
	return a.get_pay() < b.get_pay();
}

bool compare1(Technician& a, Technician& b)
{
	return a.get_pay() < b.get_pay();
}

bool compare2(Salesperson& a, Salesperson& b)
{
	return a.get_pay() < b.get_pay();
}

void report::print(string position)
{
	report a;
	a[position];
	double max;
	double min;
	if (position == "mangager")
	{
		auto max_it = max_element(MA_list->begin(), MA_list->end(), compare);
		max = max_it->salary;
		auto min_it = min_element(MA_list->begin(), MA_list->end(), compare);
		min = min_it->salary;
		cout << "min: " << min << endl;
		cout << "max: " << max << endl;
	}
	if (position == "technition")
	{
		auto max_it = max_element(T_list->begin(), T_list->end(), compare1);
		max = max_it->salary;
		auto min_it = min_element(T_list->begin(), T_list->end(), compare1);
		min = min_it->salary;
		cout << "min: " << min << endl;
		cout << "max: " << max << endl;
	}
	if (position == "salesperson")
	{
		auto max_it = max_element(SP_list->begin(), SP_list->end(), compare2);
		max = max_it->salary;
		auto min_it = min_element(SP_list->begin(), SP_list->end(), compare2);
		min = min_it->salary;
		cout << "min: " << min << endl;
		cout << "max: " << max << endl;
	}
}