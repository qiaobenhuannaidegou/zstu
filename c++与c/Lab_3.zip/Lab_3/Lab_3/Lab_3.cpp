﻿#include "Report.h"

int main()
{
	report T;

	Mangager p1("2020", "lijun", "man", 400, 78);
	Mangager p2("2021", "list", "woman", 407, 98);
	Mangager p3("2022", "ppq", "man", 800, 108);

	Technician p4("2023", "well", "woman", 1107);
	Technician p5("2024", "pig", "man", 107);
	Technician p6("2025", "jun", "woman", 207);

	Salesperson p7("2026", "ning", "man", 190, 880);
	Salesperson p8("2027", "OI", "woman", 188, 800);
	Salesperson p9("2028", "who", "man", 590, 180);

	T.insert(p1);
	T.insert(p2);
	T.insert(p3);
	T.insert(p4);
	T.insert(p5);
	T.insert(p6);
	T.insert(p7);
	T.insert(p8);
	T.insert(p9);

	T["mangager"];
	T["technician"];
	T["salesperson"];

	T.print("mangager");
	T.print("technician");
	T.print("salesperson");
}