#include "Employee.h"

ostream& operator<<(ostream& out,Mangager MA)
{
	out << "ID: " << MA.ID << endl << " NAME: " << MA.name << endl << " GENDER: " << MA.gender << endl << " SALARY: " << MA.get_pay() << endl;
	printf("%04d/%02d/%02d-%02d:%02d:%02d\n",MA.enroll_date.wYear,MA.enroll_date.wMonth,MA.enroll_date.wDay,MA.enroll_date.wHour,MA.enroll_date.wMinute,MA.enroll_date.wSecond);
	return out;
}

Mangager::Mangager(string p_ID, string p_name, string p_gender, double p_salary, double p_bonus)
{
	position = "mangager";
	ID = p_ID;
	name = p_name;
	gender = p_gender;
	salary = p_salary;
	bonus = p_bonus;
}

double Mangager::get_pay()
{
	double total = salary + bonus;
	return total;
}

ostream& operator<<(ostream& out, Technician TE)
{
	out << "ID: " << TE.ID << endl << " NAME: " << TE.name << endl << " GENDER: " << TE.gender << endl << " SALARY: " << TE.get_pay() << endl;
	printf("%04d/%02d/%02d-%02d:%02d:%02d\n", TE.enroll_date.wYear, TE.enroll_date.wMonth, TE.enroll_date.wDay, TE.enroll_date.wHour, TE.enroll_date.wMinute, TE.enroll_date.wSecond);
	return out;
}

Technician::Technician(string p_ID, string p_name, string p_gender, double p_salary)
{
	position = "technician";
	ID = p_ID;
	name = p_name;
	gender = p_gender;
	salary = p_salary;
}

double Technician::get_pay()
{
	return salary;
}

ostream& operator<<(ostream& out, Salesperson SA)
{
	out << "ID: " << SA.ID << endl << " NAME: " << SA.name << endl << " GENDER: " << SA.gender << endl << " SALARY: " << SA.get_pay() << endl;
	printf("%04d/%02d/%02d-%02d:%02d:%02d\n", SA.enroll_date.wYear, SA.enroll_date.wMonth, SA.enroll_date.wDay, SA.enroll_date.wHour, SA.enroll_date.wMinute, SA.enroll_date.wSecond);
	return out;
}

Salesperson::Salesperson(string p_ID, string p_name, string p_gender, double p_salary, double p_profits)
{
	position = "salesperson";
	ID = p_ID;
	name = p_name;
	gender = p_gender;
	salary = p_salary;
	profits = p_profits;
}

double Salesperson::get_pay()
{
	double total = salary + 0.05 * profits;
	return total;
}