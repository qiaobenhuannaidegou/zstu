#include<iostream>
#include"elevator.h"
#include <windows.h>
#include<vector>
#include<algorithm>
using namespace std;

vector<int> upline;
vector<int> downline;

elevator::elevator() : curfloor(1), targetfloor(1), choose(-1) {};

void elevator::up_display()
{
	Sleep(1000);
	curfloor++;
	cout << endl;
	cout << "Current floor: " << curfloor << endl;
}

void elevator::down_display()
{
	Sleep(1000);
	curfloor--;
	cout << "Current floor: " << curfloor << endl;
}

void elevator::running()
{
	sort(upline.begin(), upline.end());
	sort(downline.rbegin(), downline.rend());
	auto highest = upline.end() - 1;
	auto lowest = downline.end() - 1;
	int up_index = 0;
	int down_index = 0;

	while (curfloor < *highest)
	{
		up_display();
		if (curfloor == upline[up_index])
		{
			cout << "Arrived." << endl;
			up_index++;
		}
	}
	cout << endl;

	while (curfloor > *lowest)
	{
		down_display();
		if (curfloor == downline[down_index])
		{
			cout << "Arrived." << endl;
			up_index++;
		}
	}
	cout << "Arrived." << endl;
}

void elevator::slection()
{
	upline.clear();
	downline.clear();
	cout << "Please choose to set up or ser down." << endl;
	while (choose != 3)
	{
		cout << "1:up" << endl << "2:down" << endl << "3:input over" << endl;
		cout << "please input your choose:";
		cin >> choose;
		if (choose == 1)
		{
			cout << "please input the floor:";
			cin >> targetfloor;
			cout << endl;
			if (targetfloor < curfloor)
			{
				cout << "Illegal input!" << endl << endl;
			}
			else
			{
				upline.push_back(targetfloor);
			}
		}
		if (choose == 2)
		{
			cout << "please input the floor:";
			cin >> targetfloor;
			cout << endl;
			if (targetfloor > curfloor)
			{
				cout << "Illegal input!" << endl << endl;
			}
			else
			{
				downline.push_back(targetfloor);
			}
		}
		if (choose > 3)
		{
			cout << "Illegal input!" << endl << endl;
		}
	}
	choose = -1;
	running();
}