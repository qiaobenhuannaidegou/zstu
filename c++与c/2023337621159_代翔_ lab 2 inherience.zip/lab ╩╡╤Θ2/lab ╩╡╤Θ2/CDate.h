#pragma once
#include <iostream>
#include<windows.h>
using namespace std;

class CDate {
    friend class Advance_Elavator;

public:
    void show();
private:
    std::string timeString;
};