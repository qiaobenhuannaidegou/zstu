#pragma once
#include"elevator.h"
#include<iostream>
using namespace std;
#include<vector>
#include<set>
#include"Cdate.h"

class person
{
public:
	int cur_floor;

	int target_floor;

public:
	person(int curfloor, int targetfloor);
};

class Advance_Elevator :public elevator
{
public:
	vector<int>* target = new vector<int>;
	vector<int>* cur = new vector<int>;

	set<int>* target_set = new set<int>;
	set<int>* cur_set = new set<int>;

	int cur_floor;
	int max_people;
	int cur_people;
public:
	Advance_Elevator();

	void store(person a);

	void up_display();

	void down_display();

	void print();

	bool up_or_down();

	void running();
};