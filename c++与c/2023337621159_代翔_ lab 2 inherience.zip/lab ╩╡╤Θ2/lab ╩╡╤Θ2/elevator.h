#pragma once
class elevator
{
public:
	int curfloor;
	int choose;
	int targetfloor;
public:
	elevator();

	void up_display();

	void down_display();

	void slection();

	void running();
};