#include"Cdate.h"

void CDate::show()
{
    SYSTEMTIME time;
    GetLocalTime(&time);
    printf("%04d/%02d/%02d %02d:%02d:%02d\n", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond);
}