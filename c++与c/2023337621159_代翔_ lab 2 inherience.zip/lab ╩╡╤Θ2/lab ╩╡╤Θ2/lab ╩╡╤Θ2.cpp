﻿#include"elevator.h"
#include"Cdate.h"
#include"Advance_Elevator.h"


int main()
{
	CDate a;
	a.show();

	person p1(4, 7);
	person p2(-3, 2);
	person p3(-1, 4);
	person p4(6, 9);
	person p5(-2, 4);
	person p6(-2, 5);
	person p7(-2, 4);

	Advance_Elevator test;

	test.store(p1);
	test.store(p2);
	test.store(p3);
	test.store(p4);
	test.store(p5);
	test.store(p6);
	test.store(p7);

	test.running();
}