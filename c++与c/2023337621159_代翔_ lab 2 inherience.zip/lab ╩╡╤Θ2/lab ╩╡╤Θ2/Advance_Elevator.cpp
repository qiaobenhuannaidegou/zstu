#include"Advance_Elevator.h"

person::person(int curfloor, int targetfloor) :cur_floor(curfloor), target_floor(targetfloor) {};

Advance_Elevator::Advance_Elevator() :cur_floor(1),max_people(3) {};

void Advance_Elevator::store(person a)
{
	target->push_back(a.target_floor);
	if (target_set->find(a.target_floor) == target_set->end())
	{
		target_set->emplace(a.target_floor);
	}

	cur->push_back(a.cur_floor);
	if (cur_set->find(a.cur_floor) == cur_set->end())
	{
		cur_set->emplace(a.cur_floor);
	}
}

void Advance_Elevator::up_display()
{
	Sleep(1000);
	cur_floor++;
	cout << "Current floor: " << cur_floor << endl;
}

void Advance_Elevator::down_display()
{
	Sleep(1000);
	cur_floor--;
	cout << "Current floor: " << cur_floor << endl;
}


void Advance_Elevator::print()
{
	cout << "The number of people: " << target->size() << endl;
}

bool Advance_Elevator::up_or_down()
{
	int flag1 = *target_set->begin();
	int flag2 = *cur_set->begin();

	if (flag1 > flag2)
	{
		return true;//����
	}
	else return false;//����
}

void Advance_Elevator::running()
{
	print();

	set<int> stop_set;

	for (auto it : *target_set)
	{
		if (stop_set.find(it) == stop_set.end())
		{
			stop_set.emplace(it);
		}
	}
	for (auto it : *cur_set)
	{
		if (stop_set.find(it) == stop_set.end())
		{
			stop_set.emplace(it);
		}
	}

	if (up_or_down())
	{
		for (auto it = stop_set.begin(); it != stop_set.end(); it++)
		{
			while (*it > cur_floor)
			{
				up_display();
			}
			while (*it < cur_floor)
			{
				down_display();
			}
			if (*it == cur_floor)
			{
				cout << "Arrived." << endl;

				for (auto it1 : *target)
				{
					if (it1 == *it)
					{
						cur_people--;
					}
				}
				for (auto it1 : *cur)
				{
					if (it1 == *it)
					{
						cur_people++;
					}
				}

				if (cur_people > max_people)
				{
					cout << "Overweight!" << endl;
				}
			}
		}
	}
	else
	{
		for (auto it = stop_set.rbegin(); it != stop_set.rend(); it++)
		{
			while (*it < cur_floor)
			{
				down_display();
			}
			while (*it > cur_floor)
			{
				up_display();
			}
			if (*it == cur_floor)
			{
				cout << "Arrived." << endl;

				for (auto it1 : *target)
				{
					if (it1 == *it)
					{
						cur_people--;
					}
				}
				for (auto it1 : *cur)
				{
					if (it1 == *it)
					{
						cur_people++;
					}
				}

				if (cur_people > max_people)
				{
					cout << "Overweight!" << endl;
				}
			}
		}
	}

}