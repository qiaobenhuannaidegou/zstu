﻿#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Worker
{
	friend bool compare(const Worker& w1, const Worker& w2);
	friend bool operator<(const Worker& w1, const Worker& w2);
private:
	const char* name;
	int age;
	double salary;
public:
	Worker():name(nullptr),age(0),salary(0.0) {}
	Worker(const char* p_name,int p_age,double p_salary):name(p_name),age(p_age),salary(p_salary){}
	void setDate(const char* Name, int Age, double wage)
	{
		name = Name; age = Age; salary = wage;
	}
	void display()
	{
		cout << "name: " << name << endl;
		cout << "age: " << age << endl;
		cout << "salary: " << salary << endl;
	}
};

bool operator<(const Worker& w1, const Worker& w2)
{
	return w1.salary < w2.salary;
}	

bool compare(const Worker& w1, const Worker& w2)
{
	return w1.salary < w2.salary;
}	

int main()
{
	Worker a("lijun", 32, 780);
	Worker b("Jack", 23, 771);
	Worker c("PPQ", 54, 880);
	Worker d("Sam", 27, 786);
	Worker e("Troye", 96, 440);
	Worker f("Mec", 35, 890);

	vector<Worker> list1;
	vector<Worker> list2;
	
	sort(list1.begin(), list1.end(), operator<);
	sort(list2.begin(), list2.end(), operator<);

	list1.push_back(a);
	list1.push_back(b);
	list1.push_back(c);
	list2.push_back(d);
	list2.push_back(e);
	list2.push_back(f);

	vector<Worker> list_sum(list1.size() + list2.size());

	merge(list1.begin(), list1.end(), list2.begin(), list2.end(), list_sum.begin());

	for (auto it = list_sum.begin(); it != list_sum.end(); it++)
	{
		it->display();
	}
}