﻿#include<iostream>
using namespace std;

template<typename T>
class Queue
{
private:
    T* arr;
    int front, tail, size;
public:
    Queue(int size)
    {
        arr = new T[size];
        front = -1;
        tail = -1;
        this->size = size;
    }

    bool is_empty()
    {
        return front == tail ? true : false;
    }

    bool is_full()
    {
        return tail == size ? true : false;
    }

    void push(T element)
    {
        if (is_empty())
        {
            tail = 0;
            front = 0;
            arr[front] = element;
            tail++;
        }
        else if (is_full())
        {
            cout << "Queue is full." << endl;
        }
        else
        {
                arr[tail++] = element;
        }
    }

    void Pop()
    {
        if (is_empty())
        {
            cout << "Queue id empty." << endl;
        }
        else
        {
            arr[front++] = NULL;
        }
    }

    void Clear()
    {
        front = tail = -1;
    }

    T Front()
    {
        if (is_empty())
        {
            cout << "Queue is empty." << endl;
            return INT_MIN;
        }
        return arr[front];
    }
};


int main()
{
    Queue<int> a(4);
    cout << a.Front() << endl;
    a.push(1);
    a.push(2);
    a.push(3);
    a.push(4);
    a.push(5);
    cout << a.Front() << endl;
    a.Pop();
    cout << a.Front() << endl;
    a.Clear();
    cout << a.Front() << endl;
}