#include"Tape.h"

Tape::Tape(string a, string b, int c, int d, int e, float f, int g) :Publication(a, b, c, d, e, f), playtime(g) {};

void Tape::inputData()
{
	int in_playtime;
	cout << "please input the playtime: ";
	cin >> in_playtime;
	playtime = in_playtime;
}

void Tape::display() const
{
	cout << "Title: " << title << endl;
	cout << "Name: " << name << endl;
	cout << "Date: " << year << "-" << month << "-" << day << endl;
	cout << "Price: " << price << endl;
	cout << "Playtime: " << playtime << endl;
}

Tape::~Tape() {};
