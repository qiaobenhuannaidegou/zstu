#pragma once
#include"Publication.h"

class Book :public Publication
{
	int page;

public:
	Book(string a, string b, int c, int d, int e, float f, int g);

	void inputData();

	void display() const;

	~Book();
};