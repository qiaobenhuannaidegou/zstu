#pragma once
#include"Publication.h"

class Tape :public Publication
{
	int playtime;

public:
	Tape(string a, string b, int c, int d, int e, float f, int g);

	void inputData();

	void display() const;

	~Tape();
};