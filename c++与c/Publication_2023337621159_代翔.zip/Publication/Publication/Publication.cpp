﻿#include"Publication.h"

Publication::Publication(string a, string b, int c, int d, int e, float f) :title(a), name(b), year(c), month(d), day(e) ,price(f) {};

void Publication::inputData()
{
	string in_title;
	string in_name;
	int in_year;
	int in_month;
	int in_day;
	float in_price;

	cout << "please input the title of the book: ";
	cin >> in_title;
	title = in_title;

	cout << "please input the name of the book: ";
	cin >> in_name;
	name = in_name;

	cout << "please input the year of the book: ";
	cin >> in_year;
	year = in_year;

	cout << "please input the month of the book: ";
	cin >> in_month;
	month = in_month;

	cout << "please input the day of the book: ";
	cin >> in_day;
	day = in_day;

	cout << "please input the price of the book: ";
	cin >> in_price;
	price = in_price;
}

void Publication::display() const
{
	cout << "Title: " << title << endl;
	cout << "Name: " << name << endl;
	cout << "Date: " << year << "-" << month << "-" << day << endl;
	cout << "Price: " << price << endl;
}

Publication::~Publication() {};