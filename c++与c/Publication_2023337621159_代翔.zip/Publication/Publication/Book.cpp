#include"Book.h"

Book::Book(string a, string b, int c, int d, int e, float f, int g) :Publication(a, b, c, d, e, f), page(g) {};

void Book:: inputData()
{
	int in_page;
	cout << "please input the page: ";
	cin >> in_page;
	page = in_page;
}

void Book::display() const
{
	cout << "Title: " << title << endl;
	cout << "Name: " << name << endl;
	cout << "Date: " << year << "-" << month << "-" << day << endl;
	cout << "Price: " << price << endl;
	cout << "Page: " << page << endl;
}

Book::~Book() {};
