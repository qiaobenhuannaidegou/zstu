#include"Publication.h"
#include"Book.h"
#include"Tape.h"

int main()
{
	Publication test("advanture","holly",2003,4,19,36.00);
	test.display();

	Book test2("advanture", "holly", 2003, 4, 19, 36.00,89);
	test2.inputData();
	test2.display();

	Tape test3("advanture", "holly", 2003, 4, 19, 36.00, 9);
	test3.display();

	return 0;
}