#pragma once
#include<iostream>
using namespace std;
#include<string>

class Publication
{
protected:
	string title;
	string name;
	int year;
	int month;
	int day;
	float price;
public:
	Publication(string a, string b, int c, int d, int e, float f);

	void inputData();

	void display() const;

	~Publication();
};