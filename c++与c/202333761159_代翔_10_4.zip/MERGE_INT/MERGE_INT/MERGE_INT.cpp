﻿#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    vector<int> vec1;
    vector<int> vec2;

    vec1.push_back(3);
    vec1.push_back(1);
    vec1.push_back(4);

    vec2.push_back(1);
    vec2.push_back(5);
    vec2.push_back(6);

    sort(vec1.begin(), vec1.end());
    sort(vec2.begin(), vec2.end());

    vector<int> mergedVec;

    mergedVec.reserve(vec1.size() + vec2.size());
    merge(vec1.begin(), vec1.end(), vec2.begin(), vec2.end(), back_inserter(mergedVec));

    for (int num : mergedVec) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}