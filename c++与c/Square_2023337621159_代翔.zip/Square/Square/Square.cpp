﻿#include<iostream>
using namespace std;

class Rectangle
{
protected:
	double width, height;
public:
	Rectangle(int wid = 1, int hei = 1) :width(wid), height(hei) {};

	int getWidth() { return width; }

	void setWidth(int newWid) { width = newWid; }

	int getHeight() { return height; }

	void setHeight(int newHei) { height = newHei; }

	int area() { return width * height; }

	int perimeter() { return (width + height) * 2; }

	void scale(double fw, double fh) { width *= fw, height *= fh; }
};

class Square :public Rectangle
{
protected:
	double width;
public:
	Square(int wid = 1) :width(wid){};

	int getWidth() { return width; }

	void setWidth(int newWid) { width = newWid; }

	int area() { return width * width; }

	int perimeter() { return 4 * width; }

	void scale(double fw) { width *= fw; }
};

int main()
{
	Square test;

	test.setWidth(4);

	cout<<test.getWidth()<<endl;

	cout<<test.area()<<endl;
}