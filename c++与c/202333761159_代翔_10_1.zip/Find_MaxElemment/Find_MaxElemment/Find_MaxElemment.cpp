﻿#include<iostream>
using namespace std;
#include<algorithm>
#include<cstring>

template<typename T, size_t N>
T Find_MaxElement(const T(&Arr)[N], size_t size)
{
	T max = Arr[0];
	for (size_t i = 1; i < size; i++)
	{
		if (Arr[i] > max)
		{
			max = Arr[i];
		}
	}
	return max;
}

const char* Find_MaxElement(const char* Arr[], int size)
{
	const char* max = Arr[0];
	for (int i = 1; i < size; i++)
	{
		if (strcmp(Arr[i], max) > 0)
		{
			max = Arr[i];
		}
	}
	return max;
}

int main()
{
	const int arr[] = { 1,2,3,4,5,6 };
	cout << Find_MaxElement(arr, 6) << endl;

	const char* arr2[] = { "cbc","cbb","ab" };
	cout << Find_MaxElement(arr2, 3) << endl;
}