import random
import string

# 生成符合正则表达式结构的随机字符串
def generate_string_from_regex(regex):
    def generate_random_char(char_pool):
        #从字符池中随机选择字符
        return random.choice(char_pool)

    def handle_quantifier(n, m, char_pool):
        #生成指定范围内的字符数量
        count = random.randint(n, m if m is not None else n) #返回一个介于m,n之间的随机数，如果m是空，返回n
        return ''.join(generate_random_char(char_pool) for _ in range(count))

    result = [] #元组，类型（char_pool,m,n）
    i = 0
    while i < len(regex):
        if regex[i] == '\\':
            #处理转义字符
            if i + 1 < len(regex):
                char_type = regex[i + 1]
                if char_type == 'd':  #数字
                    char_pool = string.digits
                elif char_type == 'w':  #单词字符（字母、数字、下划线）
                    char_pool = string.ascii_letters + string.digits + '_'
                elif char_type == 's':  #空白字符
                    char_pool = ' \t\n\r'
                else:
                    char_pool = char_type  #其他转义字符
                result.append((char_pool, 1, 1))  #生成一个字符
                i += 2
            else:
                i += 1
        elif regex[i] == '[':
            #字符类处理
            end = regex.find(']', i)
            if end != -1:
                char_class = regex[i + 1:end]
                char_pool = []
                if 'a-z' in char_class:
                    char_pool.extend(string.ascii_lowercase)
                if 'A-Z' in char_class:
                    char_pool.extend(string.ascii_uppercase)
                if '0-9' in char_class:
                    char_pool.extend(string.digits)
                if '_' in char_class:
                    char_pool.append('_')
                result.append((char_pool, 1, 1))  #单字符的字符池
                i = end + 1
        elif regex[i] == '{':
            #量词处理
            end = regex.find('}', i)
            if end != -1 and result:
                quantifier = regex[i + 1:end].split(',')
                n = int(quantifier[0])
                m = int(quantifier[1]) if len(quantifier) > 1 else n
                char_pool, _, _ = result.pop()
                result.append((char_pool, n, m))  #应用量词
                i = end + 1
        else:
            #普通字符处理
            result.append(([regex[i]], 1, 1))  #直接生成该字符
            i += 1

    #根据字符池生成最终结果
    final_result = []
    for char_pool, n, m in result:
        final_result.append(handle_quantifier(n, m, char_pool))
    return ''.join(final_result)

def generate_multiple_strings(regex, count=1):
    """生成多个符合正则表达式的字符串"""
    return [generate_string_from_regex(regex) for _ in range(count)]


#测试生成多个匹配的正则表达式样本
regex1 = r'f[a-z0-9]{1,4}ck'  #匹配 f____ck 类型的字符串
regex2 = r'\d{2}-\d{2}-\d{4}'  #匹配日期格式：DD-MM-YYYY
regex3 = r'http://[a-z]{1,8}/[a-z0-9]{1,7}.com'  #匹配路由格式
regex4 = r'\d{3,5}'  # 匹配 3 到 5 位数字
regex5 = r'[a-zA-Z0-9_]{3,6}\d{2,4}'  #匹配 3 到 6 个字母、数字或下划线 + 2 到 4 个数字

# 生成测试样例
print(f"Regex: {regex1}")
print(f"Generated samples: {generate_multiple_strings(regex1, count=5)}")

print(f"Regex: {regex2}")
print(f"Generated samples: {generate_multiple_strings(regex2, count=5)}")

print(f"Regex: {regex3}")
print(f"Generated samples: {generate_multiple_strings(regex3, count=5)}")

print(f"Regex: {regex4}")
print(f"Generated samples: {generate_multiple_strings(regex4, count=5)}")

print(f"Regex: {regex5}")
print(f"Generated samples: {generate_multiple_strings(regex5, count=5)}")