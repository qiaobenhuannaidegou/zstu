import requests
import csv
from concurrent.futures import ThreadPoolExecutor
import json
import time
import random

date = '2024-12-23'
city_to_stringDict = {}

user_agents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/89.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 Edge/89.0.774.57'
]

with open('Advisor/城市名转为缩写.json', 'r', encoding='gbk') as f:
    city_to_stringDict = json.load(f)

def get_info(url, city_to_stringDict):
    file = open('全国飞机火车信息1.csv', 'a', encoding='utf-8', newline='')
    
    headers = {
        'user-agent': random.choice(user_agents),
        'cookie': 'route=9036359bb8a8a461c164a04f8f50b252; _jc_save_toDate=2024-12-21; _jc_save_wfdc_flag=dc; guidesStatus=off; highContrastMode=defaltMode; cursorStatus=off; BIGipServerpassport=854065418.50215.0000; _jc_save_fromStation=%u5317%u4EAC%2CBJP; _jc_save_toStation=%u4E0A%u6D77%2CSHH; _jc_save_fromDate=2024-12-22; BIGipServerotn=217055754.24610.0000',
        'Referer': 'https://kyfw.12306.cn/otn/leftTicket/init',
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    resp = requests.get(url, headers=headers)
    resp.encoding = 'utf-8'

    try:
        data = resp.json()
        results = data.get('data', {}).get('result', [])
        if not results:
            print(f"No data returned for URL: {url}")
            return

        for item in results:
            sub_items = item.split('|')
            if len(sub_items) > 10:
                train_number = sub_items[3]  # 车次
                duration = sub_items[10]  # 花费时间
                start_station = sub_items[5]  # 出发地点
                end_station = sub_items[6]  # 终点
                cost=random.randint(100,1000) # 价格(由于12306网站后端返回的数据中没有价格信息，且在前端显示是纯文本格式难以获取，所以这里随机生成一个价格)
                transitions=1 # 换乘次数(由于我们不管火车的途径站，只管终点起点，默认全部为一)

                reverse_dict = {values: keys for keys, values in city_to_stringDict.items()}

                sub_time = duration.split(':')
                time_in_minutes = int(sub_time[0]) * 60 + int(sub_time[1])

                Cstart_station = reverse_dict[start_station]
                Cend_station = reverse_dict[end_station]

                file.write(f"{train_number},{Cstart_station},{Cend_station},{time_in_minutes},{cost},{transitions}\n")

                print(f"车次: {train_number}")
                print(f"出发地点: {Cstart_station}")
                print(f"终点: {Cend_station}")
                print(f"花费时间: {duration}")

    except Exception as e:
        print(f"{url}:{e}")

    finally:
        file.close()

def get_all_url(city_to_stringDict, date):
    with ThreadPoolExecutor(10) as t:
        for key_start, value_start in city_to_stringDict.items():
            for key_end, value_end in city_to_stringDict.items():
                if value_start != value_end:
                    url = f'https://kyfw.12306.cn/otn/leftTicket/queryO?leftTicketDTO.train_date={date}&leftTicketDTO.from_station={value_start}&leftTicketDTO.to_station={value_end}&purpose_codes=ADULT'
                    t.submit(get_info, url, city_to_stringDict)
                    time.sleep(random.uniform(0.5,1)) 

if __name__ == '__main__':
    get_all_url(city_to_stringDict, date)
