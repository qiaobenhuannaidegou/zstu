var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');  // 添加 body-parser 模块
var csvParser = require('csv-parser');    // 引入 csv-parser 模块
var fs = require('fs');                   

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// 读取 CSV 文件并解析数据
let route = [];

fs.createReadStream(path.resolve(__dirname, '../全国飞机火车信息1.csv')) // 使用绝对路径来避免相对路径问题
  .pipe(csvParser({ headers: false }))
  .on('data', (row) => {
    route.push({
      number: row[0],           
      source: row[1], 
      destination: row[2],
      time: parseInt(row[3]),
      cost: parseInt(row[4]),  
      transitions: parseInt(row[5]) 
    });
  })
  .on('end', () => {
    console.log('CSV file successfully processed');
    console.log(route); // 输出解析后的结果，确保数据已加载

    // 在这里调用 graph.addEdge
    route.forEach(route => {
      console.log(route.source, route.destination, route.time, route.cost, route.transitions);  // 确保这些字段的数据是正确的
      graph.addEdge(route.number, route.source, route.destination, route.time, route.cost, route.transitions);
    });
  })
  .on('error', (err) => {
    console.error('Error reading the CSV file:', err);
  });

// 自定义 Graph 类
class Graph {
  constructor() {
    this.nodes = []; // 使用数组来存储图的节点
    this.edges = []; // 用于存储边，边是一个数组，每个元素包含起点、终点节点、时间、成本、转程次数
  }

  // 添加一条边
  addEdge(number, source, destination, time, cost, transitions) {
    console.error(`Adding edge: ${source} -> ${destination}, Time: ${time}, Cost: ${cost}, Transitions: ${transitions}`);
    if (!this.nodes.includes(source)) {
      this.nodes.push(source);
    }
    if (!this.nodes.includes(destination)) {
      this.nodes.push(destination);
    }
    this.edges.push({ number, source, destination, time, cost, transitions });
  }
  
  // 获取某个节点的所有邻居
  getNeighbors(node) {
    return this.edges.filter(edge => edge.source === node);
  }
}

class Queue {
  constructor() {
    this.queue = []; // 用于存储元素的数组
    this.head = 0;   // 队列头部索引
    this.tail = 0;   // 队列尾部索引
  }

  // 入队操作
  enqueue(element) {
    this.queue[this.tail] = element; // 在尾部位置存储元素
    this.tail++;                     // 部索引后移
  }

  // 出队操作
  dequeue() {
    if (this.isEmpty()) {
      throw new Error("Queue is empty");
    }
    const element = this.queue[this.head]; // 获取头部元素
    this.queue[this.head] = undefined;    // 清理引用（可选） 
    this.head++;                          // 头部索引后移
    return element;
  }

  // 检查队列是否为空
  isEmpty() {
    return this.head === this.tail; // 头尾索引相等表示队列为空
  }
}

function dijkstra(graph, start, end, preference, weights = null) {
  const distances = {}; // 存储到每个节点的最短距离
  const previousNodes = {}; // 存储最短路径的前驱节点
  const visited = {}; // 存储已访问的节点
  const queue = new Queue(); // 队列

  // 初始化
  graph.nodes.forEach(node => {
    distances[node] = Infinity;  // 所有节点的初始距离为无穷大
    previousNodes[node] = null;  // 前驱节点为空
    visited[node] = false;  // 所有节点都未被访问
  });

  distances[start] = 0;
  queue.enqueue({ node: start, distance: 0 });

  while (!queue.isEmpty()) {  
    const { node: currentNode, distance } = queue.dequeue();
    visited[currentNode] = true;

    if (currentNode === end) break;

    graph.getNeighbors(currentNode).forEach(neighbor => {
      const { destination, time, cost, transitions } = neighbor;
      let newDistance;

      // 根据偏好选择（时间、成本或转机次数）
      if (preference === 'time') {
        newDistance = distance + time;
      } else if (preference === 'cost') {
        newDistance = distance + cost;
      } else if (preference === 'transitions') {
        newDistance = distance + transitions;
      }else if (preference === 'customize') {
        const { timeWeight, costWeight, transitionsWeight } = weights;
        newDistance = distance + timeWeight * time + costWeight * cost + transitionsWeight * transitions;
      }

      if (newDistance < distances[destination] && !visited[destination]) {
        distances[destination] = newDistance;
        previousNodes[destination] = currentNode;
        queue.enqueue({ node: destination, distance: newDistance });
      }
    });
  }

  // 如果最终目标节点的距离仍为无穷大，表示没有找到路径
  if (distances[end] === Infinity) {
    return null;  // 没有路径
  }

  // 回溯路径
  const path = [];
  let currentNode = end;
  while (currentNode) {
    path.unshift(currentNode);  // 将当前节点添加到路径中（开头处），头插法
    currentNode = previousNodes[currentNode];
  }

  return {
    distance: distances[end],
    path
  };
}

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.json());

// 创建图实例
const graph = new Graph();

app.post('/getBestRoute', (req, res) => {
  const { source, destination, preference, weights } = req.body;

  console.log('Received request:', { source, destination, preference });

  if (!source || !destination || !preference) {
    return res.status(400).json({ message: 'Missing required parameters' });
  }

  // 找到所有匹配的起点和终点站点
  const matchingSource = graph.nodes.filter(node => node.includes(source));  // 模糊匹配所有包含源站的节点
  const matchingDestination = graph.nodes.filter(node => node.includes(destination));  // 模糊匹配所有包含目标站的节点

  console.log('Matching source stations:', matchingSource);
  console.log('Matching destination stations:', matchingDestination);

  // 对每一个匹配的源站和目标站，分别运行 Dijkstra 算法，找出所有路径
  const results = [];
  matchingSource.forEach(bestSource => {
    matchingDestination.forEach(bestDestination => {
      const bestRoute = dijkstra(graph, bestSource, bestDestination, preference, weights);
      console.log(`Best route from ${bestSource} to ${bestDestination}:`, bestRoute);

      if (!bestRoute) {
        // 如果没有找到路径，返回错误信息
        results.push({
          source: bestSource,
          destination: bestDestination,
          route: [],
          value: 'No route found',
          totalTime: 'N/A',
          totalCost: 'N/A',
          totalTransitions: 'N/A'
        });
      } else {
        // 如果找到了路径，继续处理
        const routeWithTrainNumbers = [];
        let totalTime = 0;
        let totalCost = 0;
        let totalTransitions = 0;

        // 遍历路径段
        for (let i = 0; i < bestRoute.path.length - 1; i++) {
          const station = bestRoute.path[i];
          const nextStation = bestRoute.path[i + 1];
          
          // 根据站点找到最优路径每一段对应的信息
          const routeForPart = route.filter(r => (r.source === station && r.destination === nextStation) || (r.source === nextStation && r.destination === station));

          // 按照偏好选择最优车次(redece可以将遍历一次数组，箭头函数返回最优值)
          let bestTrain = null;
          if (preference === 'time') {
            bestTrain = routeForPart.reduce((prev, curr) => (curr.time < prev.time ? curr : prev));  // 按照时间最短
          } else if (preference === 'cost') {
            bestTrain = routeForPart.reduce((prev, curr) => (curr.cost < prev.cost ? curr : prev));  // 按照成本最小
          } else if (preference === 'transitions') {
            bestTrain = routeForPart.reduce((prev, curr) => (curr.transitions < prev.transitions ? curr : prev));  // 按照转机次数最少
          } else if (preference === 'customize') {
            console.log('Customize weights:', weights); // 确认权重数据是否正确传入
            const timeWeight = weights.timeWeight || 1;  // 默认值设置为1，防止未定义
            const costWeight = weights.costWeight || 1;
            const transitionsWeight = weights.transitionsWeight || 1;

            bestTrain = routeForPart.reduce((prev, curr) => {
            const prevScore = timeWeight * prev.time + costWeight * prev.cost + transitionsWeight * prev.transitions;
            const currScore = timeWeight * curr.time + costWeight * curr.cost + transitionsWeight * curr.transitions;
            return currScore < prevScore ? curr : prev;
            });
          }

          // 选择最优车次
          if (bestTrain) {
            routeWithTrainNumbers.push({
              station,
              trainNumbers: [bestTrain.number],  // 只选择最优车次
              time: bestTrain.time,
              cost: bestTrain.cost,
              transitions: bestTrain.transitions
            });

            // 累加时间、费用和转机次数
            totalTime += bestTrain.time;
            totalCost += bestTrain.cost;
            totalTransitions += bestTrain.transitions;
          }
        }

        // 根据偏好单独显示
        let valueWithUnit;
        if (preference === 'time') {
          valueWithUnit = `${totalTime} min`;
        } else if (preference === 'cost') {
          valueWithUnit = `${totalCost} RMB`;
        } else if (preference === 'transitions') {
          valueWithUnit = `${totalTransitions} times`;
        } else if (preference === 'customize') {
          const timeWeight = weights.timeWeight || 1;
          const costWeight = weights.costWeight || 1;
          const transitionsWeight = weights.transitionsWeight || 1;
          valueWithUnit = `${timeWeight * totalTime + costWeight * totalCost + transitionsWeight * totalTransitions}`;
        }

        results.push({
          source: bestSource,
          destination: bestDestination,
          route: routeWithTrainNumbers,
          value: valueWithUnit,  // 需求值：时间、费用或转机次数
          totalTime: `${totalTime} min`,
          totalCost: `${totalCost} RMB`,
          totalTransitions: `${totalTransitions} times`
        });
      }
    });
  });

  // 如果没有找到路径，返回错误
  if (results.length === 0) {
    return res.status(404).json({ message: 'No route found' });
  }

  // 返回找到的所有最佳路径
  res.json(results);
});

// 基本路由
app.use('/', indexRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
