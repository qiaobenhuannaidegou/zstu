var pic=document.querySelector('.dog');
  
document.addEventListener('mousemove',function(e){
    //console.log(1);
    var x=e.pageX;
    var y=e.pageY;
    pic.style.left=x+'px';
    pic.style.top=y+'px';
})