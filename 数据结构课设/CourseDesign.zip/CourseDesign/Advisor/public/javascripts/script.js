document.getElementById('travel-form').addEventListener('submit', async function(event) {
  event.preventDefault();

  const source = document.getElementById('source').value;
  const destination = document.getElementById('destination').value;
  const preference = document.getElementById('preference').value;

  body = {
    source,
    destination,
    preference
  };

  if (preference === 'customize') {
    const timeWeight = parseInt(document.getElementById('time-weight').value) || 0;
    const costWeight = parseInt(document.getElementById('cost-weight').value) || 0;
    const transitionsWeight = parseInt(document.getElementById('transitions-weight').value) || 0;

    body.weights = { timeWeight, costWeight, transitionsWeight };
  }

  // 清空之前的结果n
  const resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '';

  try {
    const response = await fetch('/getBestRoute', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body:JSON.stringify(body)
    });

    const data = await response.json();

    if (response.ok) {
      // 渲染结果
      data.forEach(result => {
        const routeDetails = document.createElement('p');
        let routeText = `From ${result.source} to ${result.destination}:<br>`;

        // 渲染路径段信息
        result.route.forEach(step => {
          // 每个站点及其唯一车次
          const trainNumbers = step.trainNumbers.join(', ');
          routeText += `${step.station} (${trainNumbers}) - Time: ${step.time} min, Cost: ${step.cost} RMB, Transitions: ${step.transitions} times<br>`;
        });

        // 显示总的时间、费用和转机次数
        routeText += `<strong>Total ${preference}: ${result.value}</strong><br>`;
        routeText += `Total Time: ${result.totalTime}<br>`;
        routeText += `Total Cost: ${result.totalCost}<br>`;
        routeText += `Total Transitions: ${result.totalTransitions}<br>`;

        routeDetails.innerHTML = routeText;
        resultsDiv.appendChild(routeDetails);
      });
    } else {
      // 显示没有找到路径的消息
      resultsDiv.innerHTML = `<p>No routes found</p>`;
    }
  } catch (error) {
    console.error('Error fetching data:', error);
    resultsDiv.innerHTML = `<p>Failed to fetch data</p>`;
  }
});

document.getElementById('preference').addEventListener('change', function() {
  const weight = document.querySelector('.weight'); // 使用 querySelector 获取 class
  if (this.value === 'customize') {
    weight.style.display = 'block';
  } else {
    weight.style.display = 'none';
  }
});