import random
import csv

#中国各地区的起点和终点城市
cities = [
    '北京', '上海', '广州', '深圳', '成都', '杭州', '重庆', '武汉', '西安', '长沙', '福州',
    '南京', '沈阳', '天津', '青岛', '大连', '厦门', '济南', '合肥', '郑州', '哈尔滨',
]

#打开 CSV 文件以追加数据
with open('全国飞机火车信息1.csv', 'a', newline='', encoding='utf-8') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=["flight_number", "source", "destination", "time", "cost", "transitions"])
    
    for _ in range(100):  #生成 100 条数据
        flight_number = f"F{random.randint(1000, 9999)}"  #随机生成航班编号
        source = random.choice(cities)  #随机选择起点城市
        destination = random.choice(cities)  #随机选择终点城市
        
        #确保起点和终点不同
        while destination == source:
            destination = random.choice(cities)
        
        time = random.randint(60, 300)  #随机生成飞行时间
        cost = random.randint(1000, 2000)  #随机生成航班费用
        transitions = 1
        
        #写入数据
        writer.writerow({
            "flight_number": flight_number,
            "source": source,
            "destination": destination,
            "time": time,
            "cost": cost,
            "transitions": transitions
        })

